sap.ui.define([
			"sap/ui/core/mvc/Controller",
			"sap/ui/model/resource/ResourceModel",
			"sap/ui/model/Filter"
		], function (Controller, ResourceModel, Filter) {
			"use strict";

			var oTaux = {},
				fournisseurs = [],
				frns = [],
				fournisseur = "nuul",
				division = "nul",
				ekorg = "nul",
				annee = "nul",
				oVizFrame_ph, oDataset_ph,
				properties, sems = [],
				feedValueAxis_ph, feedValueAxis_ph, nameDim, oModel3, feedCategoryAxis_ph,
				mData, oVizModel, mois = [],
				notes = [],
				bundle,
				aFilters = [];
			return Controller.extend("ZPURCH.ZPU082_TAUX_SERVICE.controller.Chart", {

				/**
				 * Called when a controller is instantiated and its View controls (if available) are already created.
				 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
				 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.Chart
				 */
				onInit: function () {
					mData = {
						data: []
					};
					//	this.getView().byId("frn").setText("nimp");
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.getRoute("Chart").attachPatternMatched(this._onObjectMatched, this);
					fournisseurs = [];
					var i18nModel = new ResourceModel({
						bundleName: "ZPURCH.ZPU082_TAUX_SERVICE.i18n.i18n"
					});
					this.getView().setModel(i18nModel, "i18n");
					bundle = this.getView().getModel("i18n").getResourceBundle();

				},

				_onObjectMatched: function (oEvent) {
					//	var Domaine = oEvent.getParameter("arguments").domaine;
					fournisseur = oEvent.getParameter("arguments").lifnr;
					division = oEvent.getParameter("arguments").division;
					ekorg = oEvent.getParameter("arguments").ekorg;
					var annee = oEvent.getParameter("arguments").annee;

					/*	var oModel2 = new sap.ui.model.json.JSONModel(); //Creating a JSON model
						this.getView().setModel(oModel2, "oModel");*/

					this.getView().byId("frn").setText(fournisseur);
					this.getView().byId("annee").setText(annee);
					this.getView().byId("div").setText(division);
					this.getView().byId("ekorg").setText(ekorg);

					oVizModel = new sap.ui.model.json.JSONModel(mData);
					this.getView().setModel(oVizModel, "oViz");
					oModel3 = new sap.ui.model.json.JSONModel(); //Creating a JSON model
					var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZMM082_AVGDET_SRV/"); //Creating an OData model
					var oDataSet = "/zmm82_avgdetSet";
					var text = bundle.getText("mois", ["World"]);
					var nameDim = text;

					var oFilter = new Filter("Lifnr", sap.ui.model.FilterOperator.Contains, fournisseur);
					aFilters.push(oFilter);

/*					oModel.read(oDataSet,aFilters, null, false, function (oData, oResponse) {
									oModel3.setData(oData);
									for (var i = 0; i < oData.results.length; i++) {
										//	oTaux[oData.results[i].Lifnr] = oData.results[i].AvgNotedte;
										//	mois[i] = oData.results[i].Mois;
										if (oData.results[i].Lifnr === fournisseur &&
											oData.results[i].Division === division &&
											oData.results[i].Ekorg === ekorg &&
											oData.results[i].Lfgja === annee) {

											fournisseurs[i] = new Array();
											fournisseurs[i]["frn"] = oData.results[i].Lifnr;
											fournisseurs[i]["mois"] = oData.results[i].Mois;
											fournisseurs[i]["annee"] = oData.results[i].Lfgja;
											fournisseurs[i]["AVGD"] = oData.results[i].Notedate;
											fournisseurs[i]["AVGQ"] = oData.results[i].Noteqte;
											fournisseurs[i]["AVGG"] = oData.results[i].Noteglob; //+ASA061119
											fournisseurs[i]["division"] = oData.results[i].Division; //+ASA061119
											fournisseurs[i]["ekorg"] = oData.results[i].Ekorg; //+ASA061119
											frns[i] = oData.results[i].Lifnr;
										}
									}
								});*/

					oModel.read(oDataSet, {
							filters: aFilters,
							async:false,
							success: function (oData, oResponse) {
								oModel3.setData(oData);
								for (var i = 0; i < oData.results.length; i++) {
									//	oTaux[oData.results[i].Lifnr] = oData.results[i].AvgNotedte;
									//	mois[i] = oData.results[i].Mois;
									if (oData.results[i].Lifnr === fournisseur &&
										oData.results[i].Division === division &&
										oData.results[i].Ekorg === ekorg &&
										oData.results[i].Lfgja === annee) {

										fournisseurs[i] = new Array();
										fournisseurs[i]["frn"] = oData.results[i].Lifnr;
										fournisseurs[i]["mois"] = oData.results[i].Mois;
										fournisseurs[i]["annee"] = oData.results[i].Lfgja;
/*										fournisseurs[i]["AVGD"] = oData.results[i].Notedate;
										fournisseurs[i]["AVGQ"] = oData.results[i].Noteqte;
										fournisseurs[i]["AVGG"] = oData.results[i].Noteglob; //+ASA061119*/
										fournisseurs[i]["AVGD"] = oData.results[i].AvgNotedte;
										fournisseurs[i]["AVGQ"] = oData.results[i].AvgNoteqte;
										fournisseurs[i]["AVGG"] = oData.results[i].AvgNoteglob; //+ASA061119										
										fournisseurs[i]["division"] = oData.results[i].Division; //+ASA061119
										fournisseurs[i]["ekorg"] = oData.results[i].Ekorg; //+ASA061119
										frns[i] = oData.results[i].Lifnr;
									}
								}
							}
						
					});

							notes[0] = "AVGD";
							notes[1] = "AVGQ";
							notes[2] = "AVGG"; // +ASA061119
							aFilters = [];

							var res = this._toMeasures(fournisseurs);
							oVizFrame_ph = this.getView().byId("chartDe"); //Access the vizframe from view
							//Creation of Dataset
							oDataset_ph = new sap.viz.ui5.data.FlattenedDataset({
								dimensions: [{
									name: nameDim,
									value: "{oViz>mois}"
								}],
								measures: res,

								data: "{oViz>/data}"
							}); //stacked_combination
							oVizFrame_ph.setDataset(oDataset_ph); //Setting dataset to vizframe chart
							//	oVizFrame_ph.setModel(oModel3); //Setting OData model to Vizframe chart
							oVizFrame_ph.setVizType("line"); //Setting the Chart type as line
							//Defining Properties
							//		oVizFrame_ph.setVizProperties().plotArea.dataLabel.visible = !oEvent.getParameter('state');//"false";
							text = bundle.getText("chartdesc2", ["World"]);
							properties = {
								title: {
									visible: true,
									text: text
								}, //Title

								plotArea: {
									colorPalette: d3.scale.category20().range(), //Color
									dataLabel: {
										visible: true
									}
								}
							};

							oVizFrame_ph.setVizProperties(properties);

							for (var i = 0; i < 12; i++) {
								mois[i] = i;
							}

							//Creation of feed items
							feedValueAxis_ph = new sap.viz.ui5.controls.common.feeds.FeedItem({
								"uid": "valueAxis",
								"type": "Measure",
								"values": notes //[nameMeas, "nameMeas"]
							});

							feedCategoryAxis_ph = new sap.viz.ui5.controls.common.feeds.FeedItem({
								"uid": "categoryAxis",
								"type": "Dimension",
								"values": [nameDim]
							});
							//Adding the feed items to vizframe
							oVizFrame_ph.addFeed(feedValueAxis_ph);
							//	oVizFrame_ph.addFeed(feedValueAxis_ph2);
							oVizFrame_ph.addFeed(feedCategoryAxis_ph);
							fournisseurs = [];
						},

						_toMeasures: function (oSource) {
							var aRes = [],
								aRes2 = []; // aRes2 va contenir juste la 1er ligne de aRes
							mData.data = [];
							var i = 0;
							fournisseur = this.getView().byId("frn").getText();
							annee = this.getView().byId("annee").getText();
							division = this.getView().byId("div").getText();
							for (var frn in fournisseurs) {
								/*									if (fournisseurs[frn].frn === fournisseur &&
																		fournisseurs[frn].annee === annee &&
																		fournisseurs[frn].division === division &&
																		fournisseurs[frn].ekorg === ekorg
																	) {*/
								var object = {};
								i++;
								object["mois"] = fournisseurs[frn].mois; //frn["mois"];
								for (var a in oSource[frn]) {
									var c = {
										name: a,
										value: "{oViz>" + a + "}"
									};
									object[a] = oSource[frn][a];
									aRes.push(c);
									if (i === 1) {
										aRes2.push(c);
									}
								}
								mData.data.push(object);
								//	}
								//	break;
							}
							this.getView().getModel("oViz").refresh();

							var min;
							var pos = 0;
							var tmp;
							for (i = 0; i < mData.data.length; i++) {
								min = mData.data[i]["mois"];
								pos = i;
								for (var j = i; j < mData.data.length; j++) {
									if (mData.data[j]["mois"] < min) {
										pos = j;
										min = mData.data[j]["mois"];
									}
								}
								tmp = mData.data[pos]; //["AVGG"];
								//fournisseurs[pos]["AVGG"] = fournisseurs[i]["AVGG"];
								mData.data[pos] = mData.data[i];
								mData.data[i] = tmp;

							}

							return aRes2;
						},

						onBack: function () {

							oVizFrame_ph.removeAllFeeds();
							//	oVizFrame_ph.refresh();
							var router = sap.ui.core.UIComponent.getRouterFor(this);
							router.navTo("View1");
						},

						myOnClickHandler: function (oEvent) {

							//	oEvent.getParameter("data")[0].data[]
							//alert();

							//	alert(oEvent.getParameter("data")[0].data.Mois);
							//console.error(oEvent.getParameter("data")[0].data.Mois);

							var clickedData = oEvent.getParameter("data")[0].data;
							var router = sap.ui.core.UIComponent.getRouterFor(this);
							router.navTo("details", {
								fournisseur: fournisseur,
								mois: clickedData.Mois,
								annee: annee,
								division: division,
								ekorg: ekorg
							});
							oVizFrame_ph.removeAllFeeds();
						}
						/**
						 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
						 * (NOT before the first rendering! onInit() is used for that one!).
						 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.Chart
						 */
						//	onBeforeRendering: function() {
						//
						//	},

						/**
						 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
						 * This hook is the same one that SAPUI5 controls get after being rendered.
						 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.Chart
						 */
						//	onAfterRendering: function() {
						//
						//	},

						/**
						 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
						 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.Chart
						 */
						//	onExit: function() {
						//
						//	}

					});

			});