sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/SearchField',
], function (Controller, SearchField) {
	"use strict";

	var oSTable;
	var oEntry, mData, mois = "null",
		annee = "null",
		fournisseurs_bis = "",
		nonFourniss = "";
	return Controller.extend("ZPURCH.ZPU082_TAUX_SERVICE.controller.View1", {
		onInit: function () {

			mData = {
				data: []
			};

			this._smartFilterBar = this.getView().byId("smartFilterBar");
			oSTable = this.getView().byId("__table0");
			if (this._smartFilterBar) {
				this._smartFilterBar.attachFilterChange(function (oEvent) {});

				var oBasicSearchField = new SearchField();
				oBasicSearchField.attachLiveChange(function (oEvent) {
					this.getView().byId("smartFilterBar").fireFilterChange(oEvent);
				}.bind(this));

				this._smartFilterBar.setBasicSearch(oBasicSearchField);
			}
			fournisseurs_bis = "";
		},
		onCharts: function () {
			oEntry = {};
			var oSmartTable = this.getView().byId("__table0");
			var oTable = oSmartTable.getTable();
			// var oTableRows = oTable.getRows();
			var selectedIndices = oTable.getSelectedIndices();
			var selected = selectedIndices[0];
			var oBindingContext = oTable.getContextByIndex(selected);
			var oBindingPath = oBindingContext.sPath;
			var data = oBindingContext.getObject(oBindingPath);

			oEntry.lifnr = data.lifnr; //Cmgst;
			oEntry.lfgja = data.lfgja; //Vbeln;
			oEntry.division = data.division;
			oEntry.ekorg = data.ekorg;

			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("Chart", {
				lifnr: oEntry.lifnr,
				annee: oEntry.lfgja,
				division : oEntry.division,
				ekorg:oEntry.ekorg
			});

		},
		_onGenericTilePress: function () {

			oEntry = {};
			var oSmartTable = this.getView().byId("__table0");
			var oTable = oSmartTable.getTable();
			// var oTableRows = oTable.getRows();

			var selected = selectedIndices[0];
			var oBindingContext = oTable.getContextByIndex(selected);
			var oBindingPath = oBindingContext.sPath;
			var datapred = oBindingContext.getObject(oBindingPath);
			var data;
			var selectedIndices = oTable.getSelectedIndices();

			for (var i = 0; i < selectedIndices.length; i++) {
				selected = selectedIndices[i];
				oBindingContext = oTable.getContextByIndex(selected);
				oBindingPath = oBindingContext.sPath;
				data = oBindingContext.getObject(oBindingPath);
				if (data.annee === datapred.annee) {

				} else {
					// Erreur
				}
			}

			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("ChartSupp", {
				mois: mois,
				annee: annee
			});
		},
		
		charger: function(){
			var oSmartTable = this.getView().byId("__table0");
			var oTable = oSmartTable.getTable();
			// var oTableRows = oTable.getRows();
			oTable.clearSelection();
/*			var selectedIndices = oTable.getSelectedIndices();
			var selected = selectedIndices[0];*/
		},
		
		OnComparison: function () {
			fournisseurs_bis = "";
			var werks_bis = "";
			var ekorg_bis = "";
			
			nonFourniss = "";
			var oSmartTable = this.getView().byId("__table0");
			var oTable = oSmartTable.getTable();
			// var oTableRows = oTable.getRows();
			var selectedIndices = oTable.getSelectedIndices();

			var selected = selectedIndices[0];
			var oBindingContext = oTable.getContextByIndex(selected);
			var oBindingPath = oBindingContext.sPath;
			var datapred = oBindingContext.getObject(oBindingPath);

			for (var i = 0; i < selectedIndices.length; i++) {
				selected = selectedIndices[i];
				oBindingContext = oTable.getContextByIndex(selected);
				
		//		if (oBindingContext !== null){
				try{
					oBindingPath = oBindingContext.sPath;
					var data = oBindingContext.getObject(oBindingPath);
					var lcontinue = true;
					if (data.lfgja === datapred.lfgja) {
						lcontinue = true;
						datapred.lfgja = data.lfgja;
					} else {
						sap.m.MessageToast.show("Impossible de faire une comparaison sur des périodes différentes", {
							duration: 2000
						});
						lcontinue = false;
					}
	
					if (lcontinue) {
						if (i === selectedIndices.length - 1) {
							fournisseurs_bis = fournisseurs_bis + data.lifnr;
							werks_bis = werks_bis + data.division;
							ekorg_bis = ekorg_bis + data.ekorg;
							nonFourniss = nonFourniss + data.name1;
						} else {
							fournisseurs_bis = fournisseurs_bis + data.lifnr + ",";
							werks_bis = werks_bis + data.division + ",";
							ekorg_bis = ekorg_bis + data.ekorg + ",";
							
							nonFourniss = nonFourniss + data.name1 + ",";
						}
					}
				}catch(err){}
		//		}
				

			}
			if (lcontinue) {
				var router = sap.ui.core.UIComponent.getRouterFor(this);
				router.navTo("ChartSupp_BIS", {
					fournisseurs: fournisseurs_bis,
				//	names : nonFourniss,
					annee: data.lfgja,
					division: werks_bis, //data.division,
					ekorg: ekorg_bis //data.ekorg
				});

			}

		},
		onBeforeRebindTable: function () {
			mData.data = [];
			fournisseurs_bis = "";
		}
	});
});