sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter"
], function (Controller, Filter) {
	"use strict";

	var oTaux = {},
		fournisseurs = [],
		frns = [],
		fournisseur = "nuul",
		oVizFrame_ph, oDataset_ph,
		properties, sems = [],
		feedValueAxis_ph, feedValueAxis_ph, nameDim, oModel3, feedCategoryAxis_ph,
		mData, oVizModel, mois, annee,
		notes = [],
		aFilters = [],
		oFilter = {
			oStatus: {}
		};
	return Controller.extend("ZPURCH.ZPU082_TAUX_SERVICE.controller.ChartSupp", {
	/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.ChartSupp
		 */
		onInit: function () {
			mData = {
				data: []
			};
			//	this.getView().byId("frn").setText("nimp");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("ChartSupp").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (oEvent) {
			//	var Domaine = oEvent.getParameter("arguments").domaine;
			mois = oEvent.getParameter("arguments").mois;
			annee = oEvent.getParameter("arguments").annee;
			/*	var oModel2 = new sap.ui.model.json.JSONModel(); //Creating a JSON model
				this.getView().setModel(oModel2, "oModel");*/

			this.getView().byId("mois").setText(mois);
			this.getView().byId("annee").setText(annee);

			oVizModel = new sap.ui.model.json.JSONModel(mData);
			this.getView().setModel(oVizModel, "oViz");
			oModel3 = new sap.ui.model.json.JSONModel(); //Creating a JSON model
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZMM082_TAUX_SUPP_CDS/"); //Creating an OData model
			var oDataSet = "/ZMM082_taux_supp";
			var nameDim = "Fournisseur";
			oModel.read(oDataSet, null, null, false, function (oData, oResponse) {
				oModel3.setData(oData);
				for (var i = 0; i < oData.results.length; i++) {
					//	oTaux[oData.results[i].Lifnr] = oData.results[i].AvgNotedte;

					//	mois[i] = oData.results[i].Mois;

					fournisseurs[i] = new Array();
					fournisseurs[i]["frn"] = oData.results[i].lifnr;
					fournisseurs[i]["mois"] = oData.results[i].mois;
					fournisseurs[i]["Lfgja"] = oData.results[i].lfgja;
					fournisseurs[i]["AVGD"] = oData.results[i].avg_notedte;
					fournisseurs[i]["AVGQ"] = oData.results[i].avg_noteqte;

					frns[i] = oData.results[i].Lifnr;
				}
			});

			notes[0] = "AVGD";
			notes[1] = "AVGQ";

			var res = this._toMeasures(fournisseurs);

			oVizFrame_ph = this.getView().byId("chartSupp"); //Access the vizframe from view
			//Creation of Dataset
			oDataset_ph = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: nameDim,
					value: "{oViz>frn}"
				}],
				measures: res,

				data: "{oViz>/data}"
			}); //stacked_combination
			oVizFrame_ph.setDataset(oDataset_ph); //Setting dataset to vizframe chart
			//	oVizFrame_ph.setModel(oModel3); //Setting OData model to Vizframe chart
			oVizFrame_ph.setVizType("column"); //Setting the Chart type as line
			//Defining Properties
			//		oVizFrame_ph.setVizProperties().plotArea.dataLabel.visible = !oEvent.getParameter('state');//"false";
			properties = {
				title: {
					visible: true,
					text: "Taux de service fournisseurs"
				}, //Title

				plotArea: {
					colorPalette: d3.scale.category20().range(), //Color
					dataLabel: {
						visible: true
					}
				}
			};

			oVizFrame_ph.setVizProperties(properties);

			//Creation of feed items
			feedValueAxis_ph = new sap.viz.ui5.controls.common.feeds.FeedItem({
				"uid": "valueAxis",
				"type": "Measure",
				"values": notes //[nameMeas, "nameMeas"]
			});

			feedCategoryAxis_ph = new sap.viz.ui5.controls.common.feeds.FeedItem({
				"uid": "categoryAxis",
				"type": "Dimension",
				"values": [nameDim]
			});
			//Adding the feed items to vizframe
			oVizFrame_ph.addFeed(feedValueAxis_ph);
			//	oVizFrame_ph.addFeed(feedValueAxis_ph2);
			oVizFrame_ph.addFeed(feedCategoryAxis_ph);
		},
		_toMeasures: function (oSource) {
			var aRes = [],
				aRes2 = []; // aRes2 va contenir juste la 1er ligne de aRes
			mData.data = [];
			var i = 0;

			mois = this.getView().byId("mois").getText();
			annee = this.getView().byId("annee").getText();

			for (var frn in fournisseurs) {
				if ( (annee === "null" && mois === "null") || (fournisseurs[frn].Lfgja === annee &&
					fournisseurs[frn].mois === mois) ) {
					var object = {};
					i++;
					object["Supp"] = fournisseurs[frn].frn; //frn["mois"];
					for (var a in oSource[frn]) {
						var c = {
							name: a,
							value: "{oViz>" + a + "}"
						};
						object[a] = oSource[frn][a];
						aRes.push(c);
						if (i === 1) {
							aRes2.push(c);
						}
					}
					mData.data.push(object);
				}//ENDIF
				//	break;
			}//ENDFOR
			this.getView().getModel("oViz").refresh();
			return aRes2;
		},

		onBack: function () {

			oVizFrame_ph.removeAllFeeds();
			//	oVizFrame_ph.refresh();
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("View1");
		},
		myOnClickHandler: function (oEvent) {
				oVizFrame_ph.removeAllFeeds();

				var clickedData = oEvent.getParameter("data")[0].data,
					
				mois = this.getView().byId("mois").getText();
				annee = this.getView().byId("annee").getText();
				var router = sap.ui.core.UIComponent.getRouterFor(this);
				router.navTo("DetailsSupp", {
					fournisseur: clickedData.Fournisseur,
					mois: mois,
					annee: annee
				});
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.ChartSupp
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.ChartSupp
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.ChartSupp
		 */
		//	onExit: function() {
		//
		//	}


	});

});