sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";
	var oData, oModel3, oDetModel, mData,fournisseurs,annee,werks,ekorg;
	return Controller.extend("ZPURCH.ZPU082_TAUX_SERVICE.controller.Rates_view", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZPURCH.ZPU082_TAUX_SERVICE.view.Rates_view
		 */
		onInit: function () {
			mData = {
				data: []
			};

			oModel3 = new sap.ui.model.json.JSONModel(); //Creating a JSON model

			oDetModel = new sap.ui.model.json.JSONModel(mData);
			this.getView().setModel(oDetModel);
			//		this.getView().byId("__table1").bindRows("/");

			this.getView().getModel().refresh();

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Rates_view").attachPatternMatched(this._onObjectMatched, this);

			this.getView().setModel(oDetModel);
			//		this.getView().byId("__table1").bindRows("/");

			this.getView().getModel().refresh();
		},

		_onObjectMatched: function (oEvent) {
			mData = {
				data: []
			};
			fournisseurs = oEvent.getParameter("arguments").fournisseurs;
			//	var mois = oEvent.getParameter("arguments").mois;
			annee = oEvent.getParameter("arguments").annee;
			werks = oEvent.getParameter("arguments").division;
			ekorg = oEvent.getParameter("arguments").ekorg;
			
			this.getView().byId("annee").setText(annee);
			this.getView().byId("werks").setText(werks);
			this.getView().byId("ekorg").setText(ekorg);
			//	oModel3 = new sap.ui.model.json.JSONModel(mData); //Creating a JSON model
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZMM082_RATES_SRV/"); //Creating an OData model

			var oDataSet = "/ZPU082_rates_v";
			oModel.read(oDataSet, null, null, false, function (oData, oResponse) {
				oModel3.setData(oData);
				for (var i = 0; i < oData.results.length; i++) {

					mData.data.push(oData.results[i]);
				}
			});

			oDetModel = new sap.ui.model.json.JSONModel(mData);
			this.getView().setModel(oDetModel);
			//		this.getView().byId("__table1").bindRows("/");

			this.getView().getModel().refresh();
		},
		onBack: function () {
			//	fournisseur = this.getView().byId("frn").getText();
			annee = this.getView().byId("annee").getText();
			werks = this.getView().byId("werks").getText();
			ekorg = this.getView().byId("ekorg").getText();
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("ChartSupp_BIS", {
				fournisseurs: fournisseurs,
				annee: annee,
				division: werks,
				ekorg: ekorg
			});
		},		
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZPURCH.ZPU082_TAUX_SERVICE.view.Rates_view
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZPURCH.ZPU082_TAUX_SERVICE.view.Rates_view
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZPURCH.ZPU082_TAUX_SERVICE.view.Rates_view
		 */
		//	onExit: function() {
		//
		//	}

	});

});