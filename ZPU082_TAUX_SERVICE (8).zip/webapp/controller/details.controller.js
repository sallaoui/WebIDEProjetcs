sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
], function (Controller, DateFormat, Filter, Export, ExportTypeCSV) {
	"use strict";

	var fournisseur,division,ekorg, mois, oDetModel, mData, oModel3,aFilters = [];
	return Controller.extend("ZPURCH.ZPU082_TAUX_SERVICE.controller.details", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.details
		 */
		onInit: function () {
			mData = {
				data: []
			};

			oModel3 = new sap.ui.model.json.JSONModel(); //Creating a JSON model

			oDetModel = new sap.ui.model.json.JSONModel(mData);
			this.getView().setModel(oDetModel);
			//		this.getView().byId("__table1").bindRows("/");

			this.getView().getModel().refresh();

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("details").attachPatternMatched(this._onObjectMatched, this);

			this.getView().setModel(oDetModel);
			//		this.getView().byId("__table1").bindRows("/");

			this.getView().getModel().refresh();
		},

		_onObjectMatched: function (oEvent) {
			mData = {
				data: []
			};
			var fournisseur = oEvent.getParameter("arguments").fournisseur;
			mois = oEvent.getParameter("arguments").mois;
			var annee = oEvent.getParameter("arguments").annee;
			division = oEvent.getParameter("arguments").division;
			ekorg = oEvent.getParameter("arguments").ekorg;
			
			this.getView().byId("frn").setText(fournisseur);
			this.getView().byId("annee").setText(annee);
			this.getView().byId("division").setText(division);
			this.getView().byId("ekorg").setText(ekorg);

			//	oModel3 = new sap.ui.model.json.JSONModel(mData); //Creating a JSON model
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZMM082_DETAILS_SRV/"); //Creating an OData model
			
		//	var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZMM082_DETAILS_A_SRV/"); //Creating an OData model

	    	var oDataSet = "/zmm82_detailsSet";
			var oFilter = new Filter("Lifnr", sap.ui.model.FilterOperator.Contains, fournisseur);
			aFilters.push(oFilter);	    	
		//	var sObjectPath = "ZMM082_detail('" + fournisseur + "')";
		//	var oDataSet = sObjectPath;
			var nameDim = "Mois";
			oModel.read(oDataSet, {	
				filters: aFilters,
				async:false, 
				success:function (oData, oResponse) {
				oModel3.setData(oData);
				var object = {};
				for (var i = 0; i < oData.results.length; i++) {
					if (oData.results[i].Lifnr === fournisseur &&
						oData.results[i].Mois === mois &&
						oData.results[i].Lfgja === annee &&
						oData.results[i].Division === division &&
						oData.results[i].Ekorg === ekorg)
						{
						mData.data.push(oData.results[i]);
					}

				}

			}});

			oDetModel = new sap.ui.model.json.JSONModel(mData);
			this.getView().setModel(oDetModel);
			//		this.getView().byId("__table1").bindRows("/");

			this.getView().getModel().refresh();
		},

		onBack: function () {
			fournisseur = this.getView().byId("frn").getText();
			var annee = this.getView().byId("annee").getText();
			division = this.getView().byId("division").getText();
			ekorg = this.getView().byId("ekorg").getText();
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("Chart", {
				lifnr: fournisseur,
				annee: annee,
				division: division,
				ekorg:ekorg
			});
		},
		download: function () {
			/*	window.location.replace(
					"https://opera-dev.groupe-atlantic.com/sap/opu/odata/sap/ZMM149_SUPP_RAT_CPY_SRV/cpy>/zmm149_suppratioSet?$skip=0&$top=110&$format=xlsx");*/

			var oModel = this.getView().getModel();// new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZMM082_DETAILS_SRV/");
			var oExport = new Export({

				exportType: new ExportTypeCSV({
					fileExtension: "csv",
					separatorChar: ";"
				}),

				models: oModel,

				rows: {
					path: "/data"
				},
				columns: [ {
					name: "Numéro du document d'achat",
					template: {
						content: "{Ebeln}"
					}
				}, {
					name: "Poste du document d'achat",
					template: {
						content: "{Ebelp}"
					}
				},{
					name: "Supplier",
					template: {
						content: "{Lifnr}"
					}
				},{
					name: "Division",
					template: {
						content: "{Division}"
					}
				}, {
					name: "Organisation d'achats",
					template: {
						content: "{Ekorg}"
					}
				}, {
					name: "Date de livraison",
					template: {
						content: "{Daterl}"
					}
				}, {
					name: "Date prévue",
					template: {
						content: "{Datelp}"
					}
				}, {
					name: "Année",
					template: {
						content: "{Lfgja}"
					}
				}, {
					name: "Qté réceptionnée",
					template: {
						content: "{QteRec}"
					}
				}, {
					name: "Qté prévue",
					template: {
						content: "{QtePrev}"
					}
				}, {
					name: "Resp quantité",
					template: {
						content: "{RespQte}"
					}
				}, {
					name: "Resp date",
					template: {
						content: "{RespDate}"
					}
				}]
			});
			console.log(oExport);
			oExport.saveFile().catch(function (oError) {

			}).then(function () {
				oExport.destroy();
			});

		},
		formatNotedate: function (vdatu) {
			var oDate = DateFormat.getDateInstance({
				source: {
					pattern: "timestamp"
				},
				//		pattern: "dd/MM/yyyy"
			});
			if (vdatu !== null) return oDate.format(new Date(vdatu));
			return vdatu;
		},
		formatNoteqte: function (vdatu) {
			var oDate = DateFormat.getDateInstance({
				source: {
					pattern: "timestamp"
				},
				//		pattern: "dd/MM/yyyy"
			});
			if (vdatu !== null) return oDate.format(new Date(vdatu));
			return vdatu;
		},
		formatRespQte: function (color) {
			if (color === 'KO') {
				return "Error";
			} else if (color === 'OK') {
				return "Success";
			}
		},
		formatRespDate: function (color) {
			if (color === 'KO') {
				return "Error";
			} else if (color === 'OK') {
				return "Success";
			}

		},
		formatNote: function (oNote) {
			return oNote;
		},
		formatLfgja: function (Lfgja) {
				return Lfgja;
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.details
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.details
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.details
		 */
		//	onExit: function() {
		//
		//	}

	});

});