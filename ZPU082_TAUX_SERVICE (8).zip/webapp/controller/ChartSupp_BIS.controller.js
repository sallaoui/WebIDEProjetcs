sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/resource/ResourceModel",
	"sap/viz/ui5/api/env/Format",
	"sap/viz/ui5/format/ChartFormatter"
], function (Controller, Filter, ResourceModel, Format, ChartFormatter) {
	"use strict";

	var oTaux = {},
		fournisseurs = [],
		fournisseurs_bis = [],
		division_bis = [],
		ekorg_bis = [],		
		fournisseursNames = [],
		frns_bis,
		div_bis,
		eko_bis,
		names,
		find = false,
		frns = [],
		fournisseur = "nuul",
		oVizFrame_ph, oDataset_ph,
		properties, sems = [],
		feedValueAxis_ph, feedValueAxis_ph, nameDim, nameDim2,nameDim3, oModel3, feedCategoryAxis_ph,
		mData, oVizModel, mData2,
		notes = [],
		annee,
		division,
		ekorg,
		bundle,
		fields,
		res,
		isFilter,
		aFilters = [],
		oFilter = {
			oStatus: {}
		};
	return Controller.extend("ZPURCH.ZPU082_TAUX_SERVICE.controller.ChartSupp_BIS", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.ChartSupp
		 */
		onInit: function () {
			isFilter = false;
			mData = {
				data: []
			};
			//	this.getView().byId("frn").setText("nimp");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("ChartSupp_BIS").attachPatternMatched(this._onObjectMatched, this);

			var i18nModel = new ResourceModel({
				bundleName: "ZPURCH.ZPU082_TAUX_SERVICE.i18n.i18n"
			});
			this.getView().setModel(i18nModel, "i18n");
			bundle = this.getView().getModel("i18n").getResourceBundle();
			isFilter = false;
			this.getView().byId("switch01").setState(false);

		},

		_onObjectMatched: function (oEvent) {
			frns_bis = "";
			frns_bis = oEvent.getParameter("arguments").fournisseurs;
			//	names = oEvent.getParameter("arguments").names;
			annee = oEvent.getParameter("arguments").annee;
			div_bis = oEvent.getParameter("arguments").division;
			eko_bis = oEvent.getParameter("arguments").ekorg;
			
			fields = frns_bis.split(",");
			for (var i = 0; i < fields.length; i++) {
				fournisseurs_bis[i] = fields[i];
				//	fournisseursNames[i] = str[i];
			}
			fields = div_bis.split(",");
			for (var i = 0; i < fields.length; i++) {
				division_bis[i] = fields[i];
				//	fournisseursNames[i] = str[i];
			}
			fields = eko_bis.split(",");
			for (var i = 0; i < fields.length; i++) {
				ekorg_bis[i] = fields[i];
				//	fournisseursNames[i] = str[i];
			}			
			/*			this.getView().byId("mois").setText(mois);*/
			this.getView().byId("annee").setText(annee);
			this.getView().byId("div").setText(division);
			this.getView().byId("ekorg").setText(ekorg);

			oVizModel = new sap.ui.model.json.JSONModel(mData);
			this.getView().setModel(oVizModel, "oViz");
			oModel3 = new sap.ui.model.json.JSONModel(); //Creating a JSON model
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZMM082_TAUX_SUPP_CDS/"); //Creating an OData model
			var oDataSet = "/ZMM082_taux_supp";

			var text = bundle.getText("fourni", ["World"]);

			nameDim = text;

			text = bundle.getText("fourni2", ["World"]);

			nameDim2 = text;

			/*	var oBundle = this.getView().getModel("i18n").getResourceBundle();
				var sRecipient = this.getView().getModel("oViz").getProperty("/recipient/name");
				var sMsg = oBundle.getText("noteqte", [sRecipient]);
				// show message
				*/

			//	var nameDim1 = "Names";
			aFilters = [];
			for (var j = 0; j < fournisseurs_bis.length; j++) {
				var oFilter = new Filter("lifnr", sap.ui.model.FilterOperator.Contains, fournisseurs_bis[j]);
				aFilters.push(oFilter);
			}

			oModel.read(oDataSet, {
				filters: aFilters,
				async: false,

				success:function (oData, oResponse) {
					oModel3.setData(oData);
					var k = 0;
					for (i = 0; i < oData.results.length; i++) {

						for (var j = 0; j < fournisseurs_bis.length; j++) {
							if (fournisseurs_bis[j] === oData.results[i].lifnr) {
								if (annee !== null && annee === oData.results[i].lfgja && division_bis[j] !== null && division_bis[j] === oData.results[i].division &&
									ekorg_bis[j] !== null && ekorg_bis[j] === oData.results[i].ekorg) {
									find = true;
								}

							}
						}
						if (find === true) {
							find = false;
							fournisseurs[k] = new Array();
							fournisseurs[k]["frn"] = oData.results[i].name1;
							fournisseurs[k]["name"] = oData.results[i].lifnr;
							fournisseurs[k]["mois"] = oData.results[i].mois;
							fournisseurs[k]["Lfgja"] = oData.results[i].lfgja;
							fournisseurs[k]["AVGG"] = parseFloat(oData.results[i].avg_noteglob);
							fournisseurs[k]["bukrs"] = oData.results[i].bukrs;
							fournisseurs[k]["division"] = oData.results[i].division;
							fournisseurs[k]["ekorg"] = oData.results[i].ekorg;
							/*	fournisseurs[i]["AVGD"] = oData.results[i].avg_notedte;
								fournisseurs[i]["AVGQ"] = oData.results[i].avg_noteqte;*/

							frns[k] = oData.results[i].Lifnr;
							k++;
						}

					}

					var min;
					var pos = 0;
					var tmp;
					for (i = 0; i < fournisseurs.length; i++) {
						min = fournisseurs[i]["AVGG"];
						pos = i;
						for (j = i; j < fournisseurs.length; j++) {
							if (fournisseurs[j]["AVGG"] < min) {
								pos = j;
								min = fournisseurs[j]["AVGG"];
							}
						}
						tmp = fournisseurs[pos]; //["AVGG"];
						//fournisseurs[pos]["AVGG"] = fournisseurs[i]["AVGG"];
						fournisseurs[pos] = fournisseurs[i];
						fournisseurs[i] = tmp;

						/*				var tmp2 = fields[i];
										fields[pos] = fields[i];
										fields[i] = tmp2;*/
					}

				}
			});

			notes[0] = "AVGG";
			/*	notes[0] = "AVGD";
				notes[1] = "AVGQ";*/

			res = this._toMeasures(fournisseurs);

			oVizFrame_ph = this.getView().byId("chartSupp"); //Access the vizframe from view
			//Creation of Dataset
			oDataset_ph = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: nameDim,
					value: "{oViz>name}"
				}, {
					name: nameDim2,
					value: "{oViz>frn}"
				},
				{
					name: "Division",
					value: "{oViz>division}"
				}],
				measures: res,

				data: "{oViz>/data}"
			}); //stacked_combination
			oVizFrame_ph.setDataset(oDataset_ph); //Setting dataset to vizframe chart
			//	oVizFrame_ph.setModel(oModel3); //Setting OData model to Vizframe chart
			oVizFrame_ph.setVizType("column"); //Setting the Chart type as line
			//Defining Properties
			//		oVizFrame_ph.setVizProperties().plotArea.dataLabel.visible = !oEvent.getParameter('state');//"false";
			text = bundle.getText("chartdesc", ["World"]);
			properties = {
				title: {
					visible: true,
					text: text + " " + annee
				}, //Title

				plotArea: {
					colorPalette: d3.scale.category20().range(), //Color
					dataLabel: {
						visible: true
					}
				}
			};

			oVizFrame_ph.setVizProperties(properties);

			//Creation of feed items
			feedValueAxis_ph = new sap.viz.ui5.controls.common.feeds.FeedItem({
				"uid": "valueAxis",
				"type": "Measure",
				"values": notes //[nameMeas, "nameMeas"]
			});

			feedCategoryAxis_ph = new sap.viz.ui5.controls.common.feeds.FeedItem({
				"uid": "categoryAxis",
				"type": "Dimension",
				"values": [nameDim, nameDim2,"Division"]
			});
			//Adding the feed items to vizframe
			oVizFrame_ph.addFeed(feedValueAxis_ph);
			//	oVizFrame_ph.addFeed(feedValueAxis_ph2);
			oVizFrame_ph.addFeed(feedCategoryAxis_ph);

			var formatPattern = ChartFormatter.DefaultPattern;
			var oTooltip = new sap.viz.ui5.controls.VizTooltip({});
			oTooltip.connect(oVizFrame_ph.getVizUid());
			//  oTooltip.setFormatString(formatPattern.STANDARDFLOAT);

		},
		_toMeasures: function (oSource) {
			var aRes = [],
				aRes2 = []; // aRes2 va contenir juste la 1er ligne de aRes
			mData.data = [];
			var i = 0;

			/*			mois = this.getView().byId("mois").getText();
						annee = this.getView().byId("annee").getText();*/

			for (var frn in fournisseurs) {
				/*				if ((annee === "null" && mois === "null") || (fournisseurs[frn].Lfgja === annee &&
										fournisseurs[frn].mois === mois)) {*/
				var object = {};
				i++;
				object["Supp"] = fournisseurs[frn].frn; //frn["mois"];
				for (var a in oSource[frn]) {
					var c = {
						name: a,
						value: "{oViz>" + a + "}"
					};
					object[a] = oSource[frn][a];
					aRes.push(c);
					if (i === 1) {
						aRes2.push(c);
					}
				}
				mData.data.push(object);
				//		} //ENDIF
				//	break;
			} //ENDFOR
			this.getView().getModel("oViz").refresh();
			return aRes2;
		},

		onBack: function () {
			fournisseurs_bis = [];
			fournisseurs = [];
			frns_bis = "";
			oVizFrame_ph.removeAllFeeds();
			//	oVizFrame_ph.refresh();
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("View1");
		},
		charger: function () {
			oVizFrame_ph.removeAllFeeds();
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			var annee = this.getView().byId("annee").getText();
			var division = this.getView().byId("div").getText();
			var ekorg = this.getView().byId("ekorg").getText();
			
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("Rates_view", {
				fournisseurs: frns_bis,
				annee: annee,
			    division: div_bis,
				ekorg: eko_bis
			});
		},
		myOnClickHandler: function (oEvent) {
			oVizFrame_ph.removeAllFeeds();

			var clickedData = oEvent.getParameter("data")[0].data;
			var index = clickedData._context_row_number;
			var frns = fournisseurs[index].name;
			//		mois = this.getView().byId("mois").getText();
			var annee = this.getView().byId("annee").getText();
			var division = fournisseurs[index].division; //this.getView().byId("div").getText();
			var ekorg = fournisseurs[index].ekorg;//this.getView().byId("ekorg").getText();
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("DetailsSupp", {
				fournisseur: frns,
				fournisseurs: frns_bis,
				//	mois: mois,
				annee: annee,
				division: division, 
				ekorg: ekorg,
				div_bis: div_bis,
				eko_bis: eko_bis
			});
		},
		onDataChange: function () {
			var seuil, length,
				i;

			mData2 = {
				data: []
			};

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZMM082_RATES_SRV/"); //Creating an OData model

			var oDataSet = "/ZPU082_rates_v";
			oModel.read(oDataSet, null, null, false, function (oData, oResponse) {
				oModel3.setData(oData);
				for (var i = 0; i < oData.results.length; i++) {

					mData2.data.push(oData.results[i]);
				}
			});

			isFilter = !isFilter;

			if (!isFilter) {
				for (i = 0; i < fournisseurs.length; i++) {

					mData.data[i] = fournisseurs[i];

				}
			} else {
				for (i = 0; i < mData.data.length; i++) {
					seuil = this.getThresholds(mData.data[i]['bukrs']);
					if (mData.data[i]['AVGG'] > seuil) {
						mData.data.splice(i, 1);
						i--;
					}
				}
			}

			this.getView().getModel("oViz").refresh();

		},

		getThresholds: function (ekorg) {
				for (var i = 0; i < mData2.data.length; i++) {
					if (mData2.data[i]["bukrs"] === ekorg) {
						return mData2.data[i]["rate"];
					}
				}
			}
			/*		myOnClickHandler: function (oEvent) {
							oVizFrame_ph.removeAllFeeds();

							var clickedData = oEvent.getParameter("data")[0].data,

							mois = this.getView().byId("mois").getText();
							annee = this.getView().byId("annee").getText();
							var router = sap.ui.core.UIComponent.getRouterFor(this);
							router.navTo("DetailsSupp", {
								fournisseur: clickedData.Fournisseur,
								mois: mois,
								annee: annee
							});
						}*/
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.ChartSupp
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.ChartSupp
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZPURCH.ZMM082_TAUX_SUPP.view.ChartSupp
		 */
		//	onExit: function() {
		//
		//	}

	});

});