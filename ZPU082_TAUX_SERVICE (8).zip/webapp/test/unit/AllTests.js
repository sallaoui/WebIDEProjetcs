sap.ui.define([
	"ZPURCH/ZPU082_TAUX_SERVICE/test/unit/controller/View1.controller"
], function () {
	"use strict";
});