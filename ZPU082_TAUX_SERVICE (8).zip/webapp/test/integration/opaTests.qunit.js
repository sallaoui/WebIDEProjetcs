/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"ZPURCH/ZPU082_TAUX_SERVICE/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});